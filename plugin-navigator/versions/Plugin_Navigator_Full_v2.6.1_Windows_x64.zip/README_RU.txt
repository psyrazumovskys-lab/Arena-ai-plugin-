Plugin Navigator 2.6.1 — portable Windows x64
Полная автономная версия, без Trial и ключей.
Нужен Microsoft Edge WebView2 Runtime.
Цифровой подписи нет — SmartScreen может показать предупреждение.

Новое в 2.6.1:
- удалён ложный дубль Soundtoys Sandman Pro;
- Ozone Spectral Denoiser исправлен на iZotope RX Spectral De-noise;
- исправлены Micro, dbx 160, H-Reverb и stereo utility maps;
- добавлены точные карты Chakra, Ultimate Snare и diagnostic utilities;
- Session Inspector отделён от plugin chains;
- generic amp/console maps честно помечены Product-informed;
- сохранены Помощник порядка, Melodyne и 99 проверенных цепочек.
