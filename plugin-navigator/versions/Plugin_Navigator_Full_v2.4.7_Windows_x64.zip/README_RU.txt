PLUGIN NAVIGATOR 2.4.7 — ПОЛНАЯ ВЕРСИЯ ДЛЯ WINDOWS

СОСТАВ
- Plugin_Navigator_Full_v2.4.7_Windows_x64.exe — готовая автономная программа.
- CHECKSUMS_SHA256.txt — контрольные суммы файлов.
- THIRD_PARTY_LICENSES.txt — лицензия использованной настольной оболочки.

СИСТЕМНЫЕ ТРЕБОВАНИЯ
- Windows 10 или Windows 11, 64-разрядная версия.
- Microsoft Edge WebView2 Runtime.

ЗАПУСК
1. Распакуйте архив.
2. Запустите Plugin_Navigator_Full_v2.4.7_Windows_x64.exe.

ВАЖНО
- Полная версия без Trial.
- Внутри EXE — HTML 2.4.7-readable: крупнее читаемый текст.
- SmartScreen: «Подробнее» → «Выполнить в любом случае».

ПРОВЕРКА НЕИЗМЕННОСТИ
fab8225f361a1b80c899673a5a047d3ada2a7beada67d57fc85e7c5afa8e5997
