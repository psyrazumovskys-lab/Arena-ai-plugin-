Plugin Navigator 2.5.7 — portable Windows x64
Полная автономная версия, без Trial и ключей.
Нужен Microsoft Edge WebView2 Runtime.
Цифровой подписи нет — SmartScreen может показать предупреждение.

Новое в 2.5.7:
- исправлен запуск Windows EXE: открывается Plugin Navigator, а не стандартная страница Neutralinojs;
- в resources.neu встроены neutralino.config.json и resources/index.html;
- конфигурация и HTML проверяются перед созданием ZIP;
- сохранены Melodyne, 366 плагинов и все 99 проверенных цепочек.
