PLUGIN NAVIGATOR 2.4.11 — ПОЛНАЯ ВЕРСИЯ ДЛЯ WINDOWS

СОСТАВ
- Plugin_Navigator_Full_v2.4.11_Windows_x64.exe — готовая автономная программа.
- CHECKSUMS_SHA256.txt — контрольные суммы файлов.
- THIRD_PARTY_LICENSES.txt — лицензия использованной настольной оболочки.

СИСТЕМНЫЕ ТРЕБОВАНИЯ
- Windows 10 или Windows 11, 64-разрядная версия.
- Microsoft Edge WebView2 Runtime.

ЗАПУСК
1. Распакуйте архив в любую папку.
2. Запустите Plugin_Navigator_Full_v2.4.11_Windows_x64.exe.

ВАЖНО
- Полная версия без Trial и ключа.
- Внутри EXE — HTML 2.4.11-chain-analogues: в цепочке можно выбрать аналог.
- SmartScreen: «Подробнее» → «Выполнить в любом случае».

ПРОВЕРКА НЕИЗМЕННОСТИ
0912df533d8cd6c3221a22aeca37db74e8b5a4c78b6471a1f166ed22f9b352ff
