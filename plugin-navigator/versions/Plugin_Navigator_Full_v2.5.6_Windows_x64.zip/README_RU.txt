Plugin Navigator 2.5.6 — portable Windows x64
Полная автономная версия, без Trial и ключей.
Нужен Microsoft Edge WebView2 Runtime.
Цифровой подписи нет — SmartScreen может показать предупреждение.

Новое в 2.5.6:
- добавлен Celemony Melodyne с официальной карточкой и Controls;
- Melodyne включён как условный первый этап vocal-chain до EQ и dynamics;
- цепочки и порядок обработки повторно проверены;
- сохранены улучшения поиска, резервных копий и защиты данных.
