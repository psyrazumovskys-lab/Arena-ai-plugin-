PLUGIN NAVIGATOR 2.4.8 — ПОЛНАЯ ВЕРСИЯ ДЛЯ WINDOWS

СОСТАВ
- Plugin_Navigator_Full_v2.4.8_Windows_x64.exe
- CHECKSUMS_SHA256.txt
- THIRD_PARTY_LICENSES.txt

СИСТЕМНЫЕ ТРЕБОВАНИЯ
- Windows 10/11 x64, WebView2 Runtime.

ЗАПУСК
Распакуйте и запустите Plugin_Navigator_Full_v2.4.8_Windows_x64.exe.

ВАЖНО
Полная версия без Trial. HTML 2.4.8-beginner-guides: понятные новичку описания.
SmartScreen: «Подробнее» → «Выполнить в любом случае».

ПРОВЕРКА
9d169236b91fed72bc32bd37f90ba0d74af917d87727f218dc6fe5d165a56a0a
