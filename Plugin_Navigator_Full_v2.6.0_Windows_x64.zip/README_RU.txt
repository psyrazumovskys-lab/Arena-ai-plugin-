Plugin Navigator 2.6.0 — portable Windows x64
Полная автономная версия, без Trial и ключей.
Нужен Microsoft Edge WebView2 Runtime.
Цифровой подписи нет — SmartScreen может показать предупреждение.

Новое в 2.6.0:
- добавлен Помощник порядка плагинов без ИИ и интернета;
- автоматическая расстановка Inserts, Sends, Monitoring и Source;
- объяснение роли каждого этапа;
- technical warnings и допустимые creative exceptions;
- сохранены 366 плагинов, Melodyne и 99 проверенных цепочек.
